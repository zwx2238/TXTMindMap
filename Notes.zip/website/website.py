from flask import Flask, request

import sys

from string import Template

sys.path.insert(0, '..')

from node import *

import node

app = Flask(__name__)

search_box = f"""
<div class="search">
<form role="search" method="get" action="">
  <input id="search_input" type="search" name="q" autocomplete="off" placeholder="Search" required class="searchform">
</form>
</div>
"""

with open('css.css',encoding = 'utf8') as fp:
    css_file = fp.read()

css = "<style>" + css_file + "</style>"



js = """
<script src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>

<script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script> 

<script type="text/x-mathjax-config">
  MathJax.Hub.Config({
    tex2jax: {
      inlineMath: [ ['$','$'], ["\\(","\\)"] ],
      processEscapes: true
    },
  });
</script>
<script>
document.onkeydown=function(event){   
    var e = event || window.event || arguments.callee.caller.arguments[0];   
    if(e && e.keyCode>=37&&e.keyCode<=40){   
        navigate(e.keyCode);
    } 
    else if(e && e.keyCode==191){
        search();
    }
    else if(e && e.keyCode>=49&&e.keyCode<=57){
        if(e.shiftKey)
            switch_parents(e.keyCode);
        else if(e.altKey)
            switch_siblings(e.keyCode);
        else
            switch_children(e.keyCode);
    }
    else if(e &&e.keyCode==78&&e.shiftKey){
        random_next();
    }
}
function random_next(keyCode){
    next = document.getElementById("next");
    url = next.children[0].href;
    console.log(url)

    window.open(url,'_self')
    
}
function switch_children(keyCode) {
    nav = document.getElementById("children");
    nth = keyCode - 49;
    url = nav.children[nth].href;
    console.log(url)

    window.open(url,'_self')
}
function switch_siblings(keyCode) {
    nav = document.getElementById("siblings");
    nth = keyCode - 49;
    url = nav.children[nth].href;
    console.log(url)

    window.open(url,'_self')
}
function switch_parents(keyCode) {
    nav = document.getElementById("parents");
    nth = keyCode - 49;
    url = nav.children[nth].href;
    console.log(url)

    window.open(url,'_self')
}
function navigate(keyCode) {
    nav = document.getElementById("navigate");
    direction = keyCode - 37;
    url = nav.children[direction].href;
    console.log(url)

    window.open(url,'_self')
}
function search(){
    console.log("yes");
    document.getElementById('search_input').focus();
    document.getElementById('search_input').value = '';

}
</script>

"""


clock_div = """
<div id="navigate">
<a href="$left" style="display:none">左</a>
<a href="$up" style="display:none">上</a>
<a href="$right" style="display:none">右</a>
<a href="$down" style="display:none">下</a>
</div>
<div id="parents">
$parents
</div>
<div id="siblings">
$siblings
</div>
<div id="children">
$children
</div>
<div id="next">
<a href="$next" style="display:none">next</a>
</div>
"""





@app.route('/search/')
def search_detail_page():
    mode = ''
    q = request.args.get('q')

    
    if q.endswith(' -f'):
        q = q[:-3]
        recursion = False
        mode = 'full_path'


    elif q.endswith(' -a'):
        q = q[:-3]
        recursion = True
        mode = 'strict'
    else:
        recursion = False
        mode = 'strict'

    if q.startswith(('、','/')):
        q = q[1:]
    results = search(q, mode=mode)

    if len(results) == 1:
        result = results[0]

        ts = '?q={}+-f'
        direction={}
        try:
            direction['up'] = ts.format(result.parent.full_path)
        except:
            direction['up'] = ts.format(result.full_path)

        try:
            direction['down'] = ts.format(result.children[0].full_path)
        except:
            direction['down'] = ts.format(result.full_path)

        try:
            direction['left'] = ts.format(result.previous.full_path)
        except:
            direction['left'] = ts.format(result.full_path)

        try:
            direction['right'] = ts.format(result.next.full_path)
        except:
            direction['right'] = ts.format(result.full_path)

        try:
            direction['next'] = ts.format(result.random_next.full_path)
        except:
            direction['next'] = ts.format(result.full_path)


        siblings = ''
        try:
            for sibling in result.parent.children:
                siblings+= """<a href="?q={}+-f" style="display:none"></a>""".format(sibling.full_path)

        except Exception as e:
            raise e
        
        parents_str = ''
        try:
            parents = []
            node_ptr = result
            while node_ptr and node_ptr.text != "ROOT":
                parents.append(node_ptr)
                node_ptr = node_ptr.parent

            for parent in parents[::-1]:
                parents_str+= """<a href="?q={}+-f" style="display:none"></a>""".format(parent.full_path)

        except Exception as e:
            raise e

        children = ''
        try:
            for child in result.children:
                children+= """<a href="?q={}+-f" style="display:none"></a>""".format(child.full_path)

        except Exception as e:
            raise e

        direction['siblings'] = siblings
        direction['parents'] = parents_str
        direction['children'] = children

        global clock_div
        self_clock_div = clock_div

        self_clock_div = Template(self_clock_div).substitute(direction)
        top_box = search_box + self_clock_div

        return css + js + top_box + result.html_header() + result.html_body(result, recursion=recursion)

    else:
        return 'try again !'


app.debug = True
if __name__ == '__main__':
    app.run()
